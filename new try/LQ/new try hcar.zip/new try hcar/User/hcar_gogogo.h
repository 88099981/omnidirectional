#ifndef _hcar_gogogo_h
#define _hcar_gogogo_h
#include"LQ_Config.h"

//����
void hcar_gogogo(void);

#endif
