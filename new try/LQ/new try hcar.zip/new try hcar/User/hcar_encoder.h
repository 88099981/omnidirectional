#ifndef _hcar_encoder_h
#define _hcar_encoder_h
#include"LQ_Config.h"

//����
void encoder_get(void);
void encoder_print(void);

#endif
