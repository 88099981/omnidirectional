#ifndef _hcar_init_h
#define _hcar_init_h

//����
void hcar_init(void);
#endif
