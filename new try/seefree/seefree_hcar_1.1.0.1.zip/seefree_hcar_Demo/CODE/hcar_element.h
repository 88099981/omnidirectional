#ifndef _hcar_element_h
#define _hcar_element_h
#include"common.h"

//����
void hcar_start(void);

#endif
