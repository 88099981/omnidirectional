#ifndef __Serial_oscilloscope_H__
#define __Serial_oscilloscope_H__

#include "zf_uart.h"

void Data_Send(UARTN_enum uratn,unsigned short int *data);

#endif
