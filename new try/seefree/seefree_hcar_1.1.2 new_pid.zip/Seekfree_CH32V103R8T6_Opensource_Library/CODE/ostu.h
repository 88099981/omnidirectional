/*
 * ostu.h
 *
 *  Created on: 2021��2��21��
 *      Author: SLM
 */

#ifndef CODE_OSTU_H_
#define CODE_OSTU_H_

#include "common.h"

#define White 255
#define Black 0

extern uint8 get_ostu_thres();
extern void binary_img();


#endif /* CODE_OSTU_H_ */
