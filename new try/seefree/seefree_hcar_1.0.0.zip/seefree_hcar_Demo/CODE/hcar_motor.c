/**********************************************************
**0000000000000000000000000000000000000000000000000000000**
**00                                                   00**
**00               ����ȫ������ ��д                                                               00**
**00             ��Ա ����گ�� ������ ʯ����                                                   00**
**00                                                   00**
**0000000000000000000000000000000000000000000000000000000**
**00            �������ã�  motor                         00**
**0000000000000000000000000000000000000000000000000000000**
**********************************************************/
#include "hcar_motor.h"
#include "hcar_pid.h"
#include "zf_gpio.h"
#include "zf_pwm.h"
#include "hcar_init.h"
#include "hcar_uart.h"

pid_param_t pid1, pid2, pid3, pid4;

void hcar_motor_init(void)
{
    gpio_init(MOTOR1_A, GPO, 0, GPIO_PIN_CONFIG);
    pwm_init(MOTOR1_B,17000,0);
    gpio_init(MOTOR2_A, GPO, 0, GPIO_PIN_CONFIG);
    pwm_init(MOTOR2_B,17000,0);
    gpio_init(MOTOR3_A, GPO, 0, GPIO_PIN_CONFIG);
    pwm_init(MOTOR3_B,17000,0);
    gpio_init(MOTOR4_A, GPO, 0, GPIO_PIN_CONFIG);
    pwm_init(MOTOR4_B,17000,0);

    hcar_PidInit(&pid1);
    hcar_PidInit(&pid2);
    hcar_PidInit(&pid3);
    hcar_PidInit(&pid4);
    /* PID ������Ҫ���е��� */
    pid1.kp = 160;
    pid1.ki = 5;

    pid2.kp = 160;
    pid2.ki = 5;

    pid3.kp = 160;
    pid3.ki = 5;

    pid4.kp = 160;
    pid4.ki = 5;
}

void hcar_motor_control(int32 motor1, int32 motor2, int32 motor3, int32 motor4)
{
    if (motor1 > 0)
    {
        gpio_set(MOTOR1_A, 0);
        pwm_duty(MOTOR1_B, motor1);
    }
    else
    {
        gpio_set(MOTOR1_A, 1);
        pwm_duty(MOTOR1_B, PWM_DUTY_MAX+motor1);
    }

    if (motor2 > 0)
    {
        gpio_set(MOTOR2_A, 0);
        pwm_duty(MOTOR2_B, motor2);
    }
    else
    {
        gpio_set(MOTOR2_A, 1);
        pwm_duty(MOTOR2_B, PWM_DUTY_MAX+motor2);
    }

    if (motor3 > 0)
    {
        gpio_set(MOTOR3_A, 0);
        pwm_duty(MOTOR3_B, motor3);
    }
    else
    {
        gpio_set(MOTOR3_A, 1);
        pwm_duty(MOTOR3_B, PWM_DUTY_MAX+motor3);
    }

    if (motor4 > 0)
    {
        gpio_set(MOTOR4_A, 0);
        pwm_duty(MOTOR4_B, motor4);
    }
    else
    {
        gpio_set(MOTOR4_A, 1);
        pwm_duty(MOTOR4_B, PWM_DUTY_MAX+motor4);
    }
}
void hcar_speed_control(signed short x, signed short y, signed short z)
{
    // ����С���ٶȴ�С�ͷ���  ����ÿ�����ӵ�����ת��
    int32 targetSpeed1=0, targetSpeed2=0, targetSpeed3=0, targetSpeed4=0;
    int32 realSpeed1=0, realSpeed2=0, realSpeed3=0, realSpeed4=0;
    targetSpeed1 =   x + y + z;
    targetSpeed2 =  -x + y - z;
    targetSpeed3 =   x + y - z;
    targetSpeed4 =  -x + y + z;

    // ��ȡ������ֵ
    realSpeed1 = host_encoder_left; //���� ĸ���ϱ�����1��С��ǰ��Ϊ��ֵ
    realSpeed2 = host_encoder_right; //�ҵ�� ĸ���ϱ�����2��С��ǰ��Ϊ��ֵ
    realSpeed3 = slave_encoder_right; //����һ�����İ巢���ݹ���
    realSpeed4 = slave_encoder_left; //����һ�����İ巢���ݹ���

    // PID����
    hcar_PidIncCtrl(&pid1, targetSpeed1 - realSpeed1);
    hcar_PidIncCtrl(&pid2, targetSpeed2 - realSpeed2);
    hcar_PidIncCtrl(&pid3, targetSpeed3 - realSpeed3);
    hcar_PidIncCtrl(&pid4, targetSpeed4 - realSpeed4);

   /* piderror = targetSpeed1 - realSpeed1;
    pidout_p = pidp * piderror;
    pidout_i = pidi * pidlast_derivative;
    pidout_d = pidd * ((piderror - pidlast_error));

    pidlast_derivative += piderror;
    pidlast_error = piderror;

    pidout = pidout_p + pidout_i + pidout_d;*/

//    if(targetSpeed1 - realSpeed1 > 0)
//        pidout=3000;
//    else if(targetSpeed1 - realSpeed1 < 0)
//        pidout=-3000;
//    else
//        pidout = 0;
    // �������
//    MotorCtrl4w(pid1.out, pid2.out, pid3.out, pid4.out);
    hcar_motor_control(pid1.out, pid2.out, pid3.out, pid4.out);

    // �������ݵ�������λ��������   �������PID����
    //  ANO_DT_send_int16(targetSpeed1, realSpeed1, (signed short)(pid1.out), 0, 0, 0, 0, 0);

}

