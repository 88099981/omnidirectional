#include "fun.h"

void my_delay(word t)
{
  while(t--);
}